from django.apps import AppConfig


class GeneralTimetableConfig(AppConfig):
    name = 'general_timetable'
